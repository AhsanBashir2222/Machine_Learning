import streamlit as st
import pickle
import numpy as np
import pandas as pd

# Load the model and the dataframe
pipe = pickle.load(open('pipe.pkl', 'rb'))
df = pickle.load(open('df.pkl', 'rb'))

st.title("Laptop Price Predictor")

# Layout: Two columns for inputs
col1, col2 = st.columns(2)

with col1:
    company = st.selectbox('Brand', df['Company'].unique())
    type_name = st.selectbox('Type', df['TypeName'].unique())
    ram = st.selectbox('RAM (in GB)', [2, 4, 6, 8, 12, 16, 24, 32, 64])
    weight = st.number_input('Weight of the Laptop (kg)', min_value=0.5, max_value=5.0, value=2.0)

with col2:
    touchscreen = st.selectbox('Touchscreen', ['No', 'Yes'])
    ips = st.selectbox('IPS Panel', ['No', 'Yes'])
    screen_size = st.number_input('Screen Size (Inches)', min_value=10.0, max_value=20.0, value=15.6)
    resolution = st.selectbox('Screen Resolution', [
        '1920x1080', '1366x768', '1600x900', '3840x2160', '3200x1800',
        '2880x1800', '2560x1600', '2560x1440', '2304x1440'
    ])

# CPU and Storage
cpu = st.selectbox('CPU Brand', df['Cpu Brand'].unique())
hdd = st.selectbox('HDD (in GB)', [0, 128, 256, 512, 1024, 2048])
ssd = st.selectbox('SSD (in GB)', [0, 8, 128, 256, 512, 1024])
gpu = st.selectbox('GPU Brand', df['Gpu Brand'].unique())
os = st.selectbox('Operating System', df['os'].unique())

if st.button('Predict Price'):
    # 1. Feature Engineering for Input
    # Touchscreen/IPS to binary
    ts = 1 if touchscreen == 'Yes' else 0
    ips_val = 1 if ips == 'Yes' else 0

    # PPI Calculation
    X_res = int(resolution.split('x')[0])
    Y_res = int(resolution.split('x')[1])
    ppi = ((X_res**2) + (Y_res**2))**0.5 / screen_size

    # 2. Create Query Array
    # Structure must match the x_train columns exactly
    query = np.array([company, type_name, ram, weight, ts, ips_val, ppi, cpu, hdd, ssd, gpu, os])
    query = query.reshape(1, 12)

    # 3. Predict (Remember model was trained on log(Price))
    prediction = pipe.predict(pd.DataFrame(query, columns=df.drop(columns=['Price']).columns))
    final_price = np.exp(prediction)[0]

    st.header(f"The predicted price of this laptop is: Rs :{int(final_price)}")